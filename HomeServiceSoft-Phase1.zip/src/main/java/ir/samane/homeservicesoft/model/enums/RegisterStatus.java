package ir.samane.homeservicesoft.model.enums;

public enum RegisterStatus {
    REGISTERED,WAITING, APPROVED;
}
