package ir.samane.homeservicesoft.model.enums;

public enum Role {
    CUSTOMER, EXPERT, MANAGER
}