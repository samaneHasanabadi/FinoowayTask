package ir.samane.homeservicesoft.model.entity;

import javax.persistence.Entity;

@Entity
public class Customer extends User{
}
