package ir.samane.homeservicesoft.services;

public class ManagerService {
}
