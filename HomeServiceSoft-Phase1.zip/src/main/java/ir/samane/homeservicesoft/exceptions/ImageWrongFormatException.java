package ir.samane.homeservicesoft.exceptions;

public class ImageWrongFormatException extends Exception{
    public ImageWrongFormatException(String message) {
        super(message);
    }
}
