package ir.samane.homeservicesoft.exceptions;

public class ExpertStatusException extends Exception{

    public ExpertStatusException(String message){
        super(message);
    }
}
